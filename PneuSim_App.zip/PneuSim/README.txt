PneuSim 3.2 - Pneumatic, Electro-pneumatic and Hydraulic Circuit Simulator
(c) 2026 Akshaya Simha

1. Extract this whole folder (right-click the zip > Extract All).
2. Double-click PneuSim.exe.

Requires Windows 7 or later with .NET Framework 4.7.2 (already included in Windows 10/11).
Windows may say "Windows protected your PC" the first time because the program is not
code-signed: click More info > Run anyway.

NEW IN 3.2
- Troubleshooting exercises: find a hidden fault with as few checks and hints as possible
- Faults can be put into any part or tube (teachers can hand out exercise files)
- Right-click anything while simulating: live values and sliders (Inspector tab)
- Replay: step back / forward, jump to the next event, drag the time slider
- Parameter sweep (Tools): compare settings in a table and chart, export CSV
- Plotter: trigger, zoom, min / max / average between cursors, CSV and PNG export
- Pneumatic counterbalance valve (holds and lowers a hanging load smoothly)
- New parts: compressor, air receiver, shut-off valve, pressure and vacuum switch, ejector,
  suction cup, gripper, flow meter, force sensor, counter, emergency stop, idle-return roller

NEW IN 3.1
- Cutaway view (F7) of every component, not only valves
- Unsaved work is saved every minute and offered back after a crash
- Automatic numbering of new parts; copies get their own names
- Hydraulic check valve, flow control, throttle, reducing valve, single-acting cylinder
- Column numbers on every page for cross-references; ISO hollow triangles for air
- Fairer quiz, exam Back button, lesson progress remembered, many smaller fixes

NEW IN 3.0
- Check my circuit / Explain my circuit (tabs at the bottom)
- Realistic physics (toolbar "Realistic"): pressure build-up, loads, air cost per year
- Hydraulics: pump, relief valve, 4/3 valves, flow control, counterbalance, motor, accumulator
- Learn menu: 10 auto-checked lessons, quiz, timed exam, animated valve cutaway (F7)
- Plotter, calculators, parts list with costs, PDF report with title block
- Several pages per project, SVG / DXF export, GIF recording, dark mode (View menu)

Tools > Circuit Generator (Ctrl+G) designs a complete circuit from a sequence like A+ B+ B- A-.
Open the files in the Examples folders with File > Open, or use the Examples menu.
Press F9 to start the simulation and click the push buttons. F1 shows the quick guide.
