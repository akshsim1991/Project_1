PneuSim 2.0 - Pneumatic and Electro-pneumatic Circuit Simulator

1. Extract this whole folder (right-click the zip > Extract All).
2. Double-click PneuSim.exe.

Requires Windows 7 or later with .NET Framework 4.7.2 (already included in Windows 10/11).

NEW: Tools > Circuit Generator (Ctrl+G). Type a sequence like A+ B+ B- A- and PneuSim
designs the complete electro-pneumatic or pneumatic cascade circuit for you.

Open the files in the Examples folders with File > Open, or use the Examples menu.
Press F9 to start the simulation and click the push buttons. F1 shows the quick guide.
