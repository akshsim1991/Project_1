PneuSim - Pneumatic Circuit Simulator

1. Extract this whole folder (right-click the zip > Extract All).
2. Double-click PneuSim.exe.

Requires Windows 7 or later with .NET Framework 4.7.2 (already included in Windows 10/11).
Open the files in the Examples folder with File > Open, or use the Examples menu.
Press F9 to start the simulation and click the push buttons. F1 shows the quick guide.
