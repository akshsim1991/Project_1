PneuSim 3.0 - Pneumatic, Electro-pneumatic and Hydraulic Circuit Simulator
(c) 2026 Akshaya Simha

1. Extract this whole folder (right-click the zip > Extract All).
2. Double-click PneuSim.exe.

Requires Windows 7 or later with .NET Framework 4.7.2 (already included in Windows 10/11).
Windows may say "Windows protected your PC" the first time because the program is not
code-signed: click More info > Run anyway.

NEW IN 3.0
- Check my circuit / Explain my circuit (tabs at the bottom)
- Realistic physics (toolbar "Realistic"): pressure build-up, loads, air cost per year
- Hydraulics: pump, relief valve, 4/3 valves, flow control, counterbalance, motor, accumulator
- Learn menu: 10 auto-checked lessons, quiz, timed exam, animated valve cutaway (F7)
- Plotter, calculators, parts list with costs, PDF report with title block
- Several pages per project, SVG / DXF export, GIF recording, dark mode (View menu)

Tools > Circuit Generator (Ctrl+G) designs a complete circuit from a sequence like A+ B+ B- A-.
Open the files in the Examples folders with File > Open, or use the Examples menu.
Press F9 to start the simulation and click the push buttons. F1 shows the quick guide.
