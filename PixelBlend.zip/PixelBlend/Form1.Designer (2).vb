﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnAddImage = New System.Windows.Forms.Button()
        Me.lbImages = New System.Windows.Forms.ListBox()
        Me.btnCreateCollage = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.txtRows = New System.Windows.Forms.TextBox()
        Me.txtColumns = New System.Windows.Forms.TextBox()
        Me.Row = New System.Windows.Forms.Label()
        Me.Column = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.chkEnableBorder = New System.Windows.Forms.CheckBox()
        Me.cmbBorderColor = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnAddImage
        '
        Me.btnAddImage.ForeColor = System.Drawing.Color.Black
        Me.btnAddImage.Location = New System.Drawing.Point(90, 72)
        Me.btnAddImage.Name = "btnAddImage"
        Me.btnAddImage.Size = New System.Drawing.Size(132, 25)
        Me.btnAddImage.TabIndex = 0
        Me.btnAddImage.Text = "Click to add the images"
        Me.btnAddImage.UseVisualStyleBackColor = True
        '
        'lbImages
        '
        Me.lbImages.ForeColor = System.Drawing.Color.Black
        Me.lbImages.FormattingEnabled = True
        Me.lbImages.HorizontalScrollbar = True
        Me.lbImages.ItemHeight = 14
        Me.lbImages.Location = New System.Drawing.Point(12, 103)
        Me.lbImages.Name = "lbImages"
        Me.lbImages.Size = New System.Drawing.Size(210, 102)
        Me.lbImages.TabIndex = 1
        '
        'btnCreateCollage
        '
        Me.btnCreateCollage.ForeColor = System.Drawing.Color.Black
        Me.btnCreateCollage.Location = New System.Drawing.Point(102, 350)
        Me.btnCreateCollage.Name = "btnCreateCollage"
        Me.btnCreateCollage.Size = New System.Drawing.Size(120, 25)
        Me.btnCreateCollage.TabIndex = 2
        Me.btnCreateCollage.Text = "Create collage"
        Me.btnCreateCollage.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txtRows
        '
        Me.txtRows.ForeColor = System.Drawing.Color.Black
        Me.txtRows.Location = New System.Drawing.Point(134, 211)
        Me.txtRows.Name = "txtRows"
        Me.txtRows.Size = New System.Drawing.Size(88, 20)
        Me.txtRows.TabIndex = 3
        Me.txtRows.Text = "1"
        '
        'txtColumns
        '
        Me.txtColumns.ForeColor = System.Drawing.Color.Black
        Me.txtColumns.Location = New System.Drawing.Point(134, 237)
        Me.txtColumns.Name = "txtColumns"
        Me.txtColumns.Size = New System.Drawing.Size(88, 20)
        Me.txtColumns.TabIndex = 4
        Me.txtColumns.Text = "1"
        '
        'Row
        '
        Me.Row.AutoSize = True
        Me.Row.ForeColor = System.Drawing.Color.White
        Me.Row.Location = New System.Drawing.Point(52, 214)
        Me.Row.Name = "Row"
        Me.Row.Size = New System.Drawing.Size(76, 14)
        Me.Row.TabIndex = 5
        Me.Row.Text = "Enter the Row"
        '
        'Column
        '
        Me.Column.AutoSize = True
        Me.Column.ForeColor = System.Drawing.Color.White
        Me.Column.Location = New System.Drawing.Point(40, 240)
        Me.Column.Name = "Column"
        Me.Column.Size = New System.Drawing.Size(88, 14)
        Me.Column.TabIndex = 6
        Me.Column.Text = "Enter the Column"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(90, 408)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 44)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "PixelBlend" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Collage Making Software." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "© 2023 Akshaya Simha."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Arial", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(66, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 25)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "PixelBlend"
        '
        'chkEnableBorder
        '
        Me.chkEnableBorder.AutoSize = True
        Me.chkEnableBorder.ForeColor = System.Drawing.Color.White
        Me.chkEnableBorder.Location = New System.Drawing.Point(77, 263)
        Me.chkEnableBorder.Name = "chkEnableBorder"
        Me.chkEnableBorder.Size = New System.Drawing.Size(145, 18)
        Me.chkEnableBorder.TabIndex = 9
        Me.chkEnableBorder.Text = "Show the image borders"
        Me.chkEnableBorder.UseVisualStyleBackColor = True
        '
        'cmbBorderColor
        '
        Me.cmbBorderColor.BackColor = System.Drawing.Color.Black
        Me.cmbBorderColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBorderColor.ForeColor = System.Drawing.Color.White
        Me.cmbBorderColor.FormattingEnabled = True
        Me.cmbBorderColor.Location = New System.Drawing.Point(133, 287)
        Me.cmbBorderColor.Name = "cmbBorderColor"
        Me.cmbBorderColor.Size = New System.Drawing.Size(89, 22)
        Me.cmbBorderColor.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(9, 290)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 14)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Select the border color"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(174, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(19, 14)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "v1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(234, 461)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbBorderColor)
        Me.Controls.Add(Me.chkEnableBorder)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Column)
        Me.Controls.Add(Me.Row)
        Me.Controls.Add(Me.txtColumns)
        Me.Controls.Add(Me.txtRows)
        Me.Controls.Add(Me.btnCreateCollage)
        Me.Controls.Add(Me.lbImages)
        Me.Controls.Add(Me.btnAddImage)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PixelBlend"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnAddImage As Button
    Friend WithEvents lbImages As ListBox
    Friend WithEvents btnCreateCollage As Button
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents txtRows As TextBox
    Friend WithEvents txtColumns As TextBox
    Friend WithEvents Row As Label
    Friend WithEvents Column As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents chkEnableBorder As CheckBox
    Friend WithEvents cmbBorderColor As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
End Class
