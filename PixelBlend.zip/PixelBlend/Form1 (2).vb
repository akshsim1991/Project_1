﻿Imports System.IO
Imports System.Drawing

Public Class Form1
    Private ImageList As List(Of Image) = New List(Of Image)

    Private Sub btnAddImage_Click(sender As Object, e As EventArgs) Handles btnAddImage.Click
        Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
        openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp|All Files|*.*"
        openFileDialog.Multiselect = True

        If openFileDialog.ShowDialog() = DialogResult.OK Then
            For Each fileName As String In openFileDialog.FileNames
                lbImages.Items.Add(fileName)
                Dim image As Image = Image.FromFile(fileName)
                ImageList.Add(image)
            Next
        End If
    End Sub

    Private Sub btnCreateCollage_Click(sender As Object, e As EventArgs) Handles btnCreateCollage.Click

        If txtRows.TextLength = 0 Then
            MessageBox.Show("Enter the value of the Row.")

        ElseIf txtColumns.TextLength = 0 Then
            MessageBox.Show("Enter the value of the Column.")

        Else

            If ImageList.Count > 0 Then
                Dim rows As Integer = Convert.ToInt32(txtRows.Text)
                Dim columns As Integer = Convert.ToInt32(txtColumns.Text)

                Dim borderSize As Integer = If(chkEnableBorder.Checked, 1, 0)
                Dim borderColor As Color = If(chkEnableBorder.Checked, DirectCast(cmbBorderColor.SelectedItem, Color), Color.Transparent)

                Dim collageWidth As Integer = columns * (ImageList(0).Width + 2 * borderSize)
                Dim collageHeight As Integer = rows * (ImageList(0).Height + 2 * borderSize)

                Dim collage As Bitmap = New Bitmap(collageWidth, collageHeight)
                Dim g As Graphics = Graphics.FromImage(collage)
                Dim currentX As Integer = 0
                Dim currentY As Integer = 0

                Using pen As New Pen(borderColor, borderSize * 2)
                    For i As Integer = 0 To ImageList.Count - 1
                        ' Draw the border
                        g.DrawRectangle(pen, New Rectangle(currentX, currentY, ImageList(i).Width + 2 * borderSize, ImageList(i).Height + 2 * borderSize))

                        ' Draw the image
                        g.DrawImage(ImageList(i), New Rectangle(currentX + borderSize, currentY + borderSize, ImageList(i).Width, ImageList(i).Height))

                        currentX += ImageList(i).Width + 2 * borderSize
                        If i Mod columns = columns - 1 Then
                            currentX = 0
                            currentY += ImageList(i).Height + 2 * borderSize
                        End If
                    Next
                End Using

                g.Dispose()

                SaveFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
                If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
                    collage.Save(SaveFileDialog1.FileName, Imaging.ImageFormat.Jpeg)
                    MessageBox.Show("Collage saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Else
                MessageBox.Show("Please add at least one image.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub chkEnableBorder_CheckedChanged(sender As Object, e As EventArgs) Handles chkEnableBorder.CheckedChanged
        cmbBorderColor.Enabled = chkEnableBorder.Checked
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Populate the ComboBox with color choices
        cmbBorderColor.Items.Add(Color.Black)
        cmbBorderColor.Items.Add(Color.Red)
        cmbBorderColor.Items.Add(Color.Blue)
        cmbBorderColor.Items.Add(Color.Green)
        cmbBorderColor.SelectedIndex = 0
    End Sub
End Class