﻿Imports System.Data
Imports System.IO
Imports MathNet.Numerics
Imports MathNet.Numerics.LinearAlgebra
Imports System

Public Class Form1
    Dim dataTable As New DataTable()

    Private Sub btnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click
        Dim openFileDialog1 As New OpenFileDialog()

        ' Set the file dialog properties
        openFileDialog1.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*"
        openFileDialog1.Title = "Select a CSV File"

        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            ' User selected a file, proceed to import data
            Dim filePath As String = openFileDialog1.FileName

            Using reader As New StreamReader(filePath)
                Dim header = reader.ReadLine()
                Dim columns = header.Split(","c)
                For Each column In columns
                    dataTable.Columns.Add(column)
                Next

                Do While Not reader.EndOfStream
                    Dim rowValues = reader.ReadLine().Split(","c)
                    Dim row = dataTable.Rows.Add()
                    For i = 0 To columns.Length - 1
                        row(i) = rowValues(i)
                    Next
                Loop
            End Using

            DataGridView1.DataSource = dataTable
        End If
    End Sub

    Private Sub btnFitCurve_Click(sender As Object, e As EventArgs) Handles btnFitCurve.Click
        If dataTable.Columns.Contains("X_Column") AndAlso dataTable.Columns.Contains("Y_Column") Then
            Dim xData As Double() = dataTable.AsEnumerable().Select(Function(row) CDbl(row("X_Column"))).ToArray()
            Dim yData As Double() = dataTable.AsEnumerable().Select(Function(row) CDbl(row("Y_Column"))).ToArray()


            ' Example: Fit a quadratic curve
            Dim degree As Integer = 3
            Dim coefficients As Double() = MathNet.Numerics.Fit.Polynomial(xData, yData, degree)
            ' Use the coefficients for plotting or other purposes


            ' Use the coefficients as needed for your application
            ' You can display, save, or use them to generate points on the fitted curve
        Else
            MessageBox.Show("Please import data with 'X_Column' and 'Y_Column' before fitting the curve.")
        End If
    End Sub

    Private Sub btnGenerateCSV_Click(sender As Object, e As EventArgs) Handles btnGenerateCSV.Click
        Dim saveFileDialog1 As New SaveFileDialog()

        ' Set the file dialog properties
        saveFileDialog1.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*"
        saveFileDialog1.Title = "Save As CSV File"

        If saveFileDialog1.ShowDialog() = DialogResult.OK Then
            ' User selected a file, proceed to generate and save CSV
            Dim newFilePath As String = saveFileDialog1.FileName

            Using writer As New StreamWriter(newFilePath)
                ' Write header
                writer.WriteLine("X_Column,Y_Column,Z_Column")

                ' Set z to 0 for each row in the DataTable
                For Each row As DataRow In dataTable.Rows
                    Dim x = CDbl(row("X_Column"))
                    Dim y = CDbl(row("Y_Column"))
                    Dim z = 0 ' Set z to 0
                    writer.WriteLine($"{x},{y},{z}")
                Next
            End Using

            MessageBox.Show($"New CSV file generated at {newFilePath}")
        End If
    End Sub


End Class