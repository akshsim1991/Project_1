﻿Imports System.ServiceProcess

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Add columns to the DataGridView
        DataGridView1.Columns.Add("ServiceName", "Service Name")
        DataGridView1.Columns.Add("Status", "Status")
        DataGridView1.Columns.Add("Description", "Description")
        DataGridView1.Columns.Add("StartType", "Start Type")

        ' Set full-row selection mode
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        ' Load services into the DataGridView
        LoadServices()
    End Sub

    Private Sub LoadServices()
        ' Clear existing rows in the DataGridView
        DataGridView1.Rows.Clear()

        ' Get all services on the local machine
        Dim services() As ServiceController = ServiceController.GetServices()



        ' Iterate through each service and add details to the DataGridView
        For Each service As ServiceController In services
            ' Get service details
            Dim serviceName As String = service.ServiceName
            Dim status As String = If(service.Status = ServiceControllerStatus.Running, "Running", "Stopped")
            Dim description As String = GetServiceDescription(service.ServiceName)


            Dim startType As String = service.StartType.ToString()

            ' Add details to the DataGridView
            DataGridView1.Rows.Add(serviceName, status, description, startType)
        Next
    End Sub

    Private Function GetServiceDescription(serviceName As String) As String
        ' Get the service description using the registry
        Dim key As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey($"SYSTEM\CurrentControlSet\Services\{serviceName}")
        If key IsNot Nothing Then
            Dim description As Object = key.GetValue("Description")
            If description IsNot Nothing Then
                Return description.ToString()
            End If
        End If

        Return ""
    End Function

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        ' Start the selected service
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim serviceName As String = DataGridView1.SelectedRows(0).Cells("ServiceName").Value.ToString()
            Dim serviceController As New ServiceController(serviceName)

            If serviceController.Status <> ServiceControllerStatus.Running Then
                serviceController.Start()
                serviceController.WaitForStatus(ServiceControllerStatus.Running)
                LoadServices() ' Refresh the DataGridView after starting the service
            End If
        Else
            MessageBox.Show("Please select a service.")
        End If
    End Sub

    Private Sub btnStop_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        ' Stop the selected service
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim serviceName As String = DataGridView1.SelectedRows(0).Cells("ServiceName").Value.ToString()
            Dim serviceController As New ServiceController(serviceName)

            If serviceController.Status = ServiceControllerStatus.Running Then
                serviceController.Stop()
                serviceController.WaitForStatus(ServiceControllerStatus.Stopped)
                LoadServices() ' Refresh the DataGridView after stopping the service
            End If
        Else
            MessageBox.Show("Please select a service.")
        End If
    End Sub

    Private Sub btnEnable_Click(sender As Object, e As EventArgs) Handles btnEnable.Click
        ' Enable the selected service
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim serviceName As String = DataGridView1.SelectedRows(0).Cells("ServiceName").Value.ToString()
            ChangeServiceStartType(serviceName, ServiceStartMode.Automatic)
        Else
            MessageBox.Show("Please select a service.")
        End If
    End Sub

    Private Sub btnDisable_Click(sender As Object, e As EventArgs) Handles btnDisable.Click
        ' Disable the selected service
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim serviceName As String = DataGridView1.SelectedRows(0).Cells("ServiceName").Value.ToString()
            ChangeServiceStartType(serviceName, ServiceStartMode.Disabled)
        Else
            MessageBox.Show("Please select a service.")
        End If
    End Sub

    Private Sub ChangeServiceStartType(serviceName As String, startType As ServiceStartMode)
        ' Change the start type of the selected service
        Dim key As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey($"SYSTEM\CurrentControlSet\Services\{serviceName}", True)

        If key IsNot Nothing Then
            key.SetValue("Start", startType)
            key.Close()

            LoadServices() ' Refresh the DataGridView after changing the start type
        End If
    End Sub
End Class
